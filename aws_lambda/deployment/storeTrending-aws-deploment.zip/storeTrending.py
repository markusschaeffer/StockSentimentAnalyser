from stocktwits.handler.stocktwitsAPIHandler import StocktwitsAPIHandler
from stocktwits.model.trending import Trending

def storeTrending(event, context):
    
    handler = StocktwitsAPIHandler()
    model = Trending('Stocktwits_Trending')

    # get trending equities
    data = handler.getTrending()

    #print(json.dumps(data, indent=4, sort_keys=True))

    #store data
    model.store(data)

    return {
        'message' : 'end of execution'
    }