from watchlist.model.watchlist import Watchlist
from stocktwits.handler.stocktwitsAPIHandler import StocktwitsAPIHandler
from stocktwits.model.stocktwits import Stocktwits

def storeTwits(event, context):
    wl = Watchlist('./watchlist/', 'watchlist.txt', 'Watchlist')
    handler = StocktwitsAPIHandler()
    model = Stocktwits('Stocktwits')
    symbols = wl.getSymbols(filterExpression='#stocktwits = :true', expressionAttributeValues={':true': True})

    for symbol in symbols:
        print('##### Processing: ' + symbol)
        data, maxMessageId = handler.getDataForSymbol(symbol)
        model.store(data)
        
    return {
        'message' : 'end of execution'
    }